function main(require, module, exports) {
    var createGame = require('voxel-hello-world');
    var game = createGame();
}