function buffer_list(require, module, exports) {
    'use strict';

    function ownKeys(object, enumerableOnly) {
        var keys = Object.keys(object);
        if (Object.getOwnPropertySymbols) {
            var symbols = Object.getOwnPropertySymbols(object);
            if (enumerableOnly) symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
            keys.push.apply(keys, symbols);
        }
        return keys;
    }

    function _objectSpread(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i] != null ? arguments[i] : {};
            if (i % 2) {
                ownKeys(Object(source), true).forEach(function(key) {
                    _defineProperty(target, key, source[key]);
                });
            } else if (Object.getOwnPropertyDescriptors) {
                Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
            } else {
                ownKeys(Object(source)).forEach(function(key) {
                    Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
                });
            }
        }
        return target;
    }

    function _defineProperty(obj, key, value) {
        if (key in obj) {
            Object.defineProperty(obj, key, {
                value: value,
                enumerable: true,
                configurable: true,
                writable: true
            });
        } else {
            obj[key] = value;
        }
        return obj;
    }

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    function _defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }

    function _createClass(Constructor, protoProps, staticProps) {
        if (protoProps) _defineProperties(Constructor.prototype, protoProps);
        if (staticProps) _defineProperties(Constructor, staticProps);
        return Constructor;
    }

    var _require = require('buffer'),
        Buffer = _require.Buffer;

    var _require2 = require('util'),
        inspect = _require2.inspect;

    var custom = inspect && inspect.custom || 'inspect';

    function copyBuffer(src, target, offset) {
        Buffer.prototype.copy.call(src, target, offset);
    }

    module.exports =
        /*#__PURE__*/
        function() {
            function BufferList() {
                _classCallCheck(this, BufferList);

                this.head = null;
                this.tail = null;
                this.length = 0;
            }

            _createClass(BufferList, [{
                key: "push",
                value: function push(v) {
                    var entry = {
                        data: v,
                        next: null
                    };
                    if (this.length > 0) this.tail.next = entry;
                    else this.head = entry;
                    this.tail = entry;
                    ++this.length;
                }
            }, {
                key: "unshift",
                value: function unshift(v) {
                    var entry = {
                        data: v,
                        next: this.head
                    };
                    if (this.length === 0) this.tail = entry;
                    this.head = entry;
                    ++this.length;
                }
            }, {
                key: "shift",
                value: function shift() {
                    if (this.length === 0) return;
                    var ret = this.head.data;
                    if (this.length === 1) this.head = this.tail = null;
                    else this.head = this.head.next;
                    --this.length;
                    return ret;
                }
            }, {
                key: "clear",
                value: function clear() {
                    this.head = this.tail = null;
                    this.length = 0;
                }
            }, {
                key: "join",
                value: function join(s) {
                    if (this.length === 0) return '';
                    var p = this.head;
                    var ret = '' + p.data;

                    while (p = p.next) {
                        ret += s + p.data;
                    }

                    return ret;
                }
            }, {
                key: "concat",
                value: function concat(n) {
                    if (this.length === 0) return Buffer.alloc(0);
                    var ret = Buffer.allocUnsafe(n >>> 0);
                    var p = this.head;
                    var i = 0;

                    while (p) {
                        copyBuffer(p.data, ret, i);
                        i += p.data.length;
                        p = p.next;
                    }

                    return ret;
                } // Consumes a specified amount of bytes or characters from the buffered data.

            }, {
                key: "consume",
                value: function consume(n, hasStrings) {
                    var ret;

                    if (n < this.head.data.length) {
                        // `slice` is the same for buffers and strings.
                        ret = this.head.data.slice(0, n);
                        this.head.data = this.head.data.slice(n);
                    } else if (n === this.head.data.length) {
                        // First chunk is a perfect match.
                        ret = this.shift();
                    } else {
                        // Result spans more than one buffer.
                        ret = hasStrings ? this._getString(n) : this._getBuffer(n);
                    }

                    return ret;
                }
            }, {
                key: "first",
                value: function first() {
                    return this.head.data;
                } // Consumes a specified amount of characters from the buffered data.

            }, {
                key: "_getString",
                value: function _getString(n) {
                    var p = this.head;
                    var c = 1;
                    var ret = p.data;
                    n -= ret.length;

                    while (p = p.next) {
                        var str = p.data;
                        var nb = n > str.length ? str.length : n;
                        if (nb === str.length) ret += str;
                        else ret += str.slice(0, n);
                        n -= nb;

                        if (n === 0) {
                            if (nb === str.length) {
                                ++c;
                                if (p.next) this.head = p.next;
                                else this.head = this.tail = null;
                            } else {
                                this.head = p;
                                p.data = str.slice(nb);
                            }

                            break;
                        }

                        ++c;
                    }

                    this.length -= c;
                    return ret;
                } // Consumes a specified amount of bytes from the buffered data.

            }, {
                key: "_getBuffer",
                value: function _getBuffer(n) {
                    var ret = Buffer.allocUnsafe(n);
                    var p = this.head;
                    var c = 1;
                    p.data.copy(ret);
                    n -= p.data.length;

                    while (p = p.next) {
                        var buf = p.data;
                        var nb = n > buf.length ? buf.length : n;
                        buf.copy(ret, ret.length - n, 0, nb);
                        n -= nb;

                        if (n === 0) {
                            if (nb === buf.length) {
                                ++c;
                                if (p.next) this.head = p.next;
                                else this.head = this.tail = null;
                            } else {
                                this.head = p;
                                p.data = buf.slice(nb);
                            }

                            break;
                        }

                        ++c;
                    }

                    this.length -= c;
                    return ret;
                } // Make sure the linked list only shows the minimal necessary information.

            }, {
                key: custom,
                value: function value(_, options) {
                    return inspect(this, _objectSpread({}, options, {
                        // Only inspect one level.
                        depth: 0,
                        // It should not recurse.
                        customInspect: false
                    }));
                }
            }]);

            return BufferList;
        }();
}