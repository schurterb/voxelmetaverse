function init_json(require, module, exports) {
    module.exports = {
        "initEvent": [
            "type",
            "canBubble",
            "cancelable"
        ],
        "initUIEvent": [
            "type",
            "canBubble",
            "cancelable",
            "view",
            "detail"
        ],
        "initMouseEvent": [
            "type",
            "canBubble",
            "cancelable",
            "view",
            "detail",
            "screenX",
            "screenY",
            "clientX",
            "clientY",
            "ctrlKey",
            "altKey",
            "shiftKey",
            "metaKey",
            "button",
            "relatedTarget"
        ],
        "initMutationEvent": [
            "type",
            "canBubble",
            "cancelable",
            "relatedNode",
            "prevValue",
            "newValue",
            "attrName",
            "attrChange"
        ]
    }

}