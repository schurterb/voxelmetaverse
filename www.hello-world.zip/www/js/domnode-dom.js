function domnode_dom(require, module, exports) {
    module.exports = require('./lib/index')

}