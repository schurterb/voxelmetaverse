function stream(require, module, exports) {
    module.exports = require('events').EventEmitter;

}