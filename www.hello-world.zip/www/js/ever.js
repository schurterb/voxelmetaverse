function ever(require, module, exports) {
    var EventEmitter = require('events').EventEmitter;

    module.exports = function(elem) {
        return new Ever(elem);
    };

    function Ever(elem) {
        this.element = elem;
    }

    Ever.prototype = new EventEmitter;

    Ever.prototype.on = function(name, cb, useCapture) {
        if (!this._events) this._events = {};
        if (!this._events[name]) this._events[name] = [];
        this._events[name].push(cb);
        this.element.addEventListener(name, cb, useCapture || false);

        return this;
    };
    Ever.prototype.addListener = Ever.prototype.on;

    Ever.prototype.removeListener = function(type, listener, useCapture) {
        if (!this._events) this._events = {};
        this.element.removeEventListener(type, listener, useCapture || false);

        var xs = this.listeners(type);
        var ix = xs.indexOf(listener);
        if (ix >= 0) xs.splice(ix, 1);

        return this;
    };

    Ever.prototype.removeAllListeners = function(type) {
        var self = this;

        function removeAll(t) {
            var xs = self.listeners(t);
            for (var i = 0; i < xs.length; i++) {
                self.removeListener(t, xs[i]);
            }
        }

        if (type) {
            removeAll(type)
        } else if (self._events) {
            for (var key in self._events) {
                if (key) removeAll(key);
            }
        }
        return EventEmitter.prototype.removeAllListeners.apply(self, arguments);
    }

    var initSignatures = require('./init.json');

    Ever.prototype.emit = function(name, ev) {
        if (typeof name === 'object') {
            ev = name;
            name = ev.type;
        }

        if (!isEvent(ev)) {
            var type = Ever.typeOf(name);

            var opts = ev || {};
            if (opts.type === undefined) opts.type = name;

            ev = document.createEvent(type + 's');
            var init = typeof ev['init' + type] === 'function' ?
                'init' + type : 'initEvent';

            var sig = initSignatures[init];
            var used = {};
            var args = [];

            for (var i = 0; i < sig.length; i++) {
                var key = sig[i];
                args.push(opts[key]);
                used[key] = true;
            }
            ev[init].apply(ev, args);

            // attach remaining unused options to the object
            for (var key in opts) {
                if (!used[key]) ev[key] = opts[key];
            }
        }
        return this.element.dispatchEvent(ev);
    };

    function isEvent(ev) {
        var s = Object.prototype.toString.call(ev);
        return /[object S+Event]/.test(s);
    }

    Ever.types = require('./types.json');
    Ever.typeOf = (function() {
        var types = {};
        for (var key in Ever.types) {
            var ts = Ever.types[key];
            for (var i = 0; i < ts.length; i++) {
                types[ts[i]] = key;
            }
        }

        return function(name) {
            return types[name] || 'Event';
        };
    })();;

}